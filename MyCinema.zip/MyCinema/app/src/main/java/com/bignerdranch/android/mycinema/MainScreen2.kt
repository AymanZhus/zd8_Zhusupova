package com.bignerdranch.android.mycinema

import androidx.appcompat.app.AppCompatActivity

class MainScreen2: AppCompatActivity() {

}
